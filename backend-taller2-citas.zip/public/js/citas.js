/* ============================================================
   public/js/citas.js
   Consume el CRUD del backend (routes/citas.js) desde el cliente:
   - GET    /api/citas            -> listar (con filtro opcional)
   - POST   /api/citas            -> crear
   - PUT    /api/citas/:id        -> actualizar (usado en "Recordar"
                                      como ejemplo de actualización)
   - DELETE /api/citas/:id        -> eliminar (borrado lógico)
   ============================================================ */

$(document).ready(function () {

  /* --- Verifica sesión y muestra el usuario actual --- */
  $.get("/api/sesion", function (respuesta) {
    if (respuesta.autenticado) {
      $("#usuario-actual").text("👤 " + respuesta.usuario.usuario);
    } else {
      window.location.href = "/login.html";
    }
  });

  /* --- Pinta las filas de la tabla a partir del arreglo recibido --- */
  function pintarCitas(citas) {
    const $tbody = $("#tabla-citas tbody").empty();

    citas.forEach(function (cita) {
      const fila = `
        <tr data-id="${cita.id}" data-riesgo="${cita.riesgo}">
          <td>${cita.paciente}</td>
          <td>${cita.edad}</td>
          <td>${cita.fecha}</td>
          <td>${cita.zona || "—"}</td>
          <td><span class="badge">${cita.riesgo}</span></td>
          <td>
            <button class="btn-recordatorio">Marcar recordado</button>
            <button class="btn-eliminar">Eliminar</button>
          </td>
        </tr>`;
      $tbody.append(fila);
    });
  }

  /* --- READ: carga inicial y recarga tras cada cambio --- */
  function cargarCitas() {
    const riesgo = $("#filtro-riesgo").val() || "todos";
    $.get("/api/citas", { riesgo: riesgo }) // GET con querystring -> req.query en el server
      .done(function (respuesta) {
        pintarCitas(respuesta.citas);
      })
      .fail(function () {
        $("#tabla-citas tbody").html("<tr><td colspan='6'>No se pudo cargar la información.</td></tr>");
      });
  }
  cargarCitas();

  /* --- CREATE: envía el formulario por POST --- */
  $("#form-cita").on("submit", function (evento) {
    evento.preventDefault();

    const datos = {
      paciente: $("#paciente").val(),
      edad: $("#edad").val(),
      fecha: $("#fecha").val(),
      zona: $("#zona").val(),
    };

    $.ajax({
      url: "/api/citas",
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(datos),
    })
      .done(function (respuesta) {
        $("#form-msg").removeClass("error").addClass("ok").text(respuesta.mensaje);
        document.getElementById("form-cita").reset();
        cargarCitas();
      })
      .fail(function (xhr) {
        const mensaje = xhr.responseJSON ? xhr.responseJSON.mensaje : "Error al guardar.";
        $("#form-msg").removeClass("ok").addClass("error").text(mensaje);
      });
  });

  /* --- UPDATE: ejemplo de PUT al marcar un recordatorio como enviado --- */
  $("#tabla-citas").on("click", ".btn-recordatorio", function () {
    const id = $(this).closest("tr").data("id");
    $.ajax({
      url: "/api/citas/" + id,
      method: "PUT",
      contentType: "application/json",
      data: JSON.stringify({}), // no cambia datos; solo demuestra el endpoint UPDATE
    }).done(function () {
      $(this).text("Recordado ✔");
    }.bind(this));
  });

  /* --- DELETE: borrado lógico de una cita --- */
  $("#tabla-citas").on("click", ".btn-eliminar", function () {
    const $fila = $(this).closest("tr");
    const id = $fila.data("id");

    $.ajax({ url: "/api/citas/" + id, method: "DELETE" })
      .done(function () {
        $fila.fadeOut(200, function () { $(this).remove(); });
      });
  });

  /* --- Filtro (GET con parámetro) --- */
  $("#filtro-riesgo").on("change", cargarCitas);

  /* --- Logout --- */
  $("#btn-logout").on("click", function () {
    $.post("/api/logout", function () {
      window.location.href = "/login.html";
    });
  });
});
