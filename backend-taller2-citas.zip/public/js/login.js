/* ============================================================
   public/js/login.js
   Envía el formulario de login mediante POST (fetch) y procesa
   la respuesta JSON del servidor (routes/auth.js).
   ============================================================ */

$(document).ready(function () {
  $("#form-login").on("submit", function (evento) {
    evento.preventDefault();

    const datos = {
      usuario: $("#usuario").val().trim(),
      password: $("#password").val().trim(),
    };

    $.ajax({
      url: "/api/login",     // coincide con el atributo action del formulario
      method: "POST",        // coincide con el atributo method del formulario
      contentType: "application/json",
      data: JSON.stringify(datos),
    })
      .done(function (respuesta) {
        $("#login-msg").removeClass("error").addClass("ok").text(respuesta.mensaje);
        // Redirige a la ruta protegida del servidor (requiere sesión).
        window.location.href = "/dashboard";
      })
      .fail(function (xhr) {
        const mensaje = xhr.responseJSON ? xhr.responseJSON.mensaje : "Error al iniciar sesión.";
        $("#login-msg").removeClass("ok").addClass("error").text(mensaje);
      });
  });
});
