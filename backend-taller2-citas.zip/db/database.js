/* ============================================================
   db/database.js
   Módulo de CONEXIÓN a la base de datos (SQLite).
   - Maneja la ruta/credenciales de forma centralizada (variables
     de entorno, con valores por defecto para desarrollo local).
   - Envuelve la apertura de la conexión en try/catch para
     gestionar excepciones.
   - Crea las tablas si no existen (usuarios y citas).
   ============================================================ */

const path = require("path");
const Database = require("better-sqlite3");

// Las "credenciales" de una BD de archivo son la ruta y los
// permisos; en una BD como MySQL/Postgres aquí irían host, user,
// password y database, idealmente tomados de variables de entorno.
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "citas.db");

let db;
try {
  db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  console.log("[DB] Conexión establecida correctamente:", DB_PATH);
} catch (error) {
  // Manejo de excepciones de conexión: se registra y se detiene
  // la aplicación porque sin BD el servidor no puede operar.
  console.error("[DB] Error al conectar con la base de datos:", error.message);
  process.exit(1);
}

// --- Creación de tablas (idempotente: sólo si no existen) ---
db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    rol TEXT NOT NULL DEFAULT 'operador'
  );

  CREATE TABLE IF NOT EXISTS citas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paciente TEXT NOT NULL,
    edad INTEGER NOT NULL,
    fecha TEXT NOT NULL,
    zona TEXT,
    riesgo TEXT NOT NULL DEFAULT 'bajo',
    activo INTEGER NOT NULL DEFAULT 1
  );
`);

// Usuario de prueba por defecto (solo si la tabla está vacía).
// En un proyecto real la contraseña se guardaría con hash (bcrypt).
const totalUsuarios = db.prepare("SELECT COUNT(*) AS n FROM usuarios").get().n;
if (totalUsuarios === 0) {
  db.prepare("INSERT INTO usuarios (usuario, password, rol) VALUES (?, ?, ?)")
    .run("admin", "admin123", "administrador");
  console.log('[DB] Usuario de prueba creado -> usuario: "admin" / password: "admin123"');
}

// Datos de ejemplo para citas (solo si la tabla está vacía).
const totalCitas = db.prepare("SELECT COUNT(*) AS n FROM citas").get().n;
if (totalCitas === 0) {
  const insertarCita = db.prepare(
    "INSERT INTO citas (paciente, edad, fecha, zona, riesgo) VALUES (?, ?, ?, ?, ?)"
  );
  insertarCita.run("J. Rodríguez", 34, "2026-09-02 10:00", "Colón", "alto");
  insertarCita.run("M. Gómez", 61, "2026-09-02 11:30", "Panamá", "medio");
  insertarCita.run("A. Torres", 28, "2026-09-02 13:00", "Colón", "bajo");
}

module.exports = db;
