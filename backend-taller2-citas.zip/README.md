# Taller: Procesamiento de Datos de Formularios (POST/GET) + CRUD + Sesiones

Backend en **Node.js + Express + SQLite** para el proyecto
*"Modelo predictivo para identificar riesgos de inasistencia en sistemas de citas médicas"*.

## Requerimientos que cubre este proyecto

**A. Procesamiento de datos de formularios (POST/GET)**
- Servidor local con Express (`server.js`), equivalente a activar XAMPP/Node.
- Formularios HTML con `action` y `method` configurados (`public/login.html`, `public/dashboard.html`).
- Recepción de parámetros con `req.body` (POST) y `req.query` (GET, filtro por riesgo).
- Sanitización de todos los campos de texto con `sanitize-html` (previene XSS).
- Respuestas en formato **JSON**.

**B. Conexión y consulta a base de datos (CRUD básico)**
- Conexión centralizada y manejo de excepciones en `db/database.js` (SQLite).
- CRUD completo de citas en `routes/citas.js`, todo con **consultas preparadas** (`?`) para evitar inyección SQL:
  - Create → `POST /api/citas`
  - Read → `GET /api/citas` y `GET /api/citas/:id`
  - Update → `PUT /api/citas/:id`
  - Delete → `DELETE /api/citas/:id` (borrado lógico, campo `activo`)
- Autenticación y sesiones con `express-session` (cookie) en `routes/auth.js`:
  - `POST /api/login`, `POST /api/logout`, `GET /api/sesion`
- Middleware `middleware/auth.js` que protege las rutas de citas y el dashboard.

## Estructura del proyecto

```
backend-taller2/
├── server.js              # Servidor Express (rutas, sesión, estáticos)
├── db/
│   └── database.js        # Conexión SQLite + creación de tablas + datos de ejemplo
├── middleware/
│   └── auth.js             # Protege rutas según sesión activa
├── routes/
│   ├── auth.js              # login / logout / estado de sesión
│   └── citas.js             # CRUD de citas (sanitizado y con consultas preparadas)
└── public/
    ├── login.html
    ├── dashboard.html
    ├── style.css
    └── js/
        ├── login.js
        ├── citas.js
        └── vendor/jquery.min.js
```

## Cómo ejecutarlo

```bash
npm install
node server.js
```

Abre `http://localhost:3000/login.html` en el navegador.

**Usuario de prueba:** `admin` / **Contraseña:** `admin123`
(se crea automáticamente la primera vez que corres el servidor).

## Cómo probar el CRUD y la sanitización manualmente (opcional, vía curl)

```bash
# Login (guarda la cookie de sesión en cookies.txt)
curl -c cookies.txt -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"usuario":"admin","password":"admin123"}'

# Listar citas (requiere sesión)
curl -b cookies.txt http://localhost:3000/api/citas

# Crear cita (prueba de sanitización: el <script> se elimina automáticamente)
curl -b cookies.txt -X POST http://localhost:3000/api/citas \
  -H "Content-Type: application/json" \
  -d '{"paciente":"<script>alert(1)</script>Pedro","edad":45,"fecha":"2026-09-05 09:00","zona":"Colón"}'
```

## Para el entregable del taller

1. **Código fuente**: sube esta carpeta completa (o el .zip) al repositorio del proyecto.
2. **Captura del proceso de inicio a fin**: toma pantallazos de:
   - `npm install` corriendo sin errores.
   - `node server.js` mostrando "Servidor activo en http://localhost:3000".
   - La pantalla de login, un intento fallido y uno correcto.
   - El dashboard con las citas cargadas desde la base de datos.
   - Crear una cita nueva y verla aparecer en la tabla.
   - Eliminar una cita y ver que desaparece de la lista.
   - Cerrar sesión y comprobar que `/api/citas` vuelve a rechazar el acceso.
