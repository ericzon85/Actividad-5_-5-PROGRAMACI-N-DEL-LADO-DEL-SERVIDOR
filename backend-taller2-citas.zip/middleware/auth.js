/* ============================================================
   middleware/auth.js
   Middleware que protege rutas: solo deja pasar si existe una
   sesión activa (creada al hacer login). Se usa como "guardia"
   antes de las rutas CRUD del backend.
   ============================================================ */

function requiereSesion(req, res, next) {
  if (req.session && req.session.usuario) {
    // Sesión válida: continúa hacia la ruta solicitada.
    return next();
  }

  // Sin sesión: responde según el tipo de solicitud (API vs. navegador).
  if (req.originalUrl.startsWith("/api/")) {
    return res.status(401).json({ ok: false, mensaje: "Sesión no iniciada o expirada." });
  }
  return res.redirect("/login.html");
}

module.exports = { requiereSesion };
