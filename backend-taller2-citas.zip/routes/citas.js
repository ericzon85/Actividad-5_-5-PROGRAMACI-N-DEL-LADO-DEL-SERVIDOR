/* ============================================================
   routes/citas.js
   CRUD BÁSICO de la tabla "citas", protegido por sesión.
   Todas las consultas usan parámetros preparados (?) para
   evitar inyección SQL. Todo texto de entrada se sanitiza
   para evitar XSS antes de guardarlo o devolverlo.
   ============================================================ */

const express = require("express");
const sanitizeHtml = require("sanitize-html");
const db = require("../db/database");
const { requiereSesion } = require("../middleware/auth");

const router = express.Router();

function limpiar(texto) {
  return sanitizeHtml(String(texto ?? "").trim(), { allowedTags: [], allowedAttributes: {} });
}

// Reglas simples de negocio: clasifica el riesgo (igual lógica
// que en el front, ahora también validada en el servidor).
function clasificarRiesgo(edad) {
  if (edad >= 60) return "alto";
  if (edad >= 40) return "medio";
  return "bajo";
}

// Todas las rutas de este archivo requieren sesión iniciada.
router.use(requiereSesion);

/* --- READ (todas / con filtro opcional por GET) ---
   GET /api/citas?riesgo=alto  -> usa req.query (parámetros de la URL) */
router.get("/", (req, res) => {
  const { riesgo } = req.query;

  let filas;
  if (riesgo && riesgo !== "todos") {
    filas = db.prepare("SELECT * FROM citas WHERE activo = 1 AND riesgo = ? ORDER BY fecha")
      .all(limpiar(riesgo));
  } else {
    filas = db.prepare("SELECT * FROM citas WHERE activo = 1 ORDER BY fecha").all();
  }

  res.json({ ok: true, total: filas.length, citas: filas });
});

/* --- READ (una sola cita por id) ---
   GET /api/citas/:id */
router.get("/:id", (req, res) => {
  const id = Number(req.params.id);
  const fila = db.prepare("SELECT * FROM citas WHERE id = ? AND activo = 1").get(id);

  if (!fila) {
    return res.status(404).json({ ok: false, mensaje: "Cita no encontrada." });
  }
  res.json({ ok: true, cita: fila });
});

/* --- CREATE ---
   POST /api/citas  (recibe req.body -> formulario con method="POST") */
router.post("/", (req, res) => {
  const paciente = limpiar(req.body.paciente);
  const edad = Number(req.body.edad);
  const fecha = limpiar(req.body.fecha);
  const zona = limpiar(req.body.zona);

  // Validación de servidor (nunca confiar solo en la validación del cliente).
  if (!paciente || paciente.length < 3) {
    return res.status(400).json({ ok: false, mensaje: "El nombre del paciente es inválido." });
  }
  if (!Number.isFinite(edad) || edad <= 0 || edad > 120) {
    return res.status(400).json({ ok: false, mensaje: "La edad debe estar entre 1 y 120." });
  }
  if (!fecha) {
    return res.status(400).json({ ok: false, mensaje: "La fecha es obligatoria." });
  }

  const riesgo = clasificarRiesgo(edad);

  // INSERT con consulta preparada.
  const resultado = db.prepare(
    "INSERT INTO citas (paciente, edad, fecha, zona, riesgo) VALUES (?, ?, ?, ?, ?)"
  ).run(paciente, edad, fecha, zona, riesgo);

  const nuevaCita = db.prepare("SELECT * FROM citas WHERE id = ?").get(resultado.lastInsertRowid);
  res.status(201).json({ ok: true, mensaje: "Cita creada.", cita: nuevaCita });
});

/* --- UPDATE ---
   PUT /api/citas/:id  (filtrado explícito por id) */
router.put("/:id", (req, res) => {
  const id = Number(req.params.id);
  const existente = db.prepare("SELECT * FROM citas WHERE id = ? AND activo = 1").get(id);

  if (!existente) {
    return res.status(404).json({ ok: false, mensaje: "Cita no encontrada." });
  }

  // Solo actualiza los campos que llegaron; conserva el resto.
  const paciente = req.body.paciente !== undefined ? limpiar(req.body.paciente) : existente.paciente;
  const edad = req.body.edad !== undefined ? Number(req.body.edad) : existente.edad;
  const fecha = req.body.fecha !== undefined ? limpiar(req.body.fecha) : existente.fecha;
  const zona = req.body.zona !== undefined ? limpiar(req.body.zona) : existente.zona;
  const riesgo = clasificarRiesgo(edad);

  db.prepare(
    "UPDATE citas SET paciente = ?, edad = ?, fecha = ?, zona = ?, riesgo = ? WHERE id = ?"
  ).run(paciente, edad, fecha, zona, riesgo, id);

  const actualizada = db.prepare("SELECT * FROM citas WHERE id = ?").get(id);
  res.json({ ok: true, mensaje: "Cita actualizada.", cita: actualizada });
});

/* --- DELETE (borrado lógico, no físico) ---
   DELETE /api/citas/:id */
router.delete("/:id", (req, res) => {
  const id = Number(req.params.id);
  const existente = db.prepare("SELECT * FROM citas WHERE id = ? AND activo = 1").get(id);

  if (!existente) {
    return res.status(404).json({ ok: false, mensaje: "Cita no encontrada." });
  }

  // Borrado lógico: se conserva el registro pero se marca inactivo.
  db.prepare("UPDATE citas SET activo = 0 WHERE id = ?").run(id);
  res.json({ ok: true, mensaje: "Cita eliminada (borrado lógico)." });
});

module.exports = router;
