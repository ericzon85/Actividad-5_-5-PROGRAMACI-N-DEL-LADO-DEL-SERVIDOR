/* ============================================================
   routes/auth.js
   Gestión de AUTENTICACIÓN Y SESIONES.
   - POST /api/login   -> valida credenciales, crea la sesión (cookie)
   - POST /api/logout  -> destruye la sesión
   - GET  /api/sesion  -> indica si hay una sesión activa
   ============================================================ */

const express = require("express");
const sanitizeHtml = require("sanitize-html");
const db = require("../db/database");

const router = express.Router();

// Función de sanitización reutilizable: limpia cualquier texto
// recibido del cliente para prevenir inyección de HTML/JS (XSS).
function limpiar(texto) {
  return sanitizeHtml(String(texto ?? "").trim(), { allowedTags: [], allowedAttributes: {} });
}

/* --- POST /api/login (recibe req.body -> POST) --- */
router.post("/login", (req, res) => {
  const usuario = limpiar(req.body.usuario);
  const password = limpiar(req.body.password);

  if (!usuario || !password) {
    return res.status(400).json({ ok: false, mensaje: "Usuario y contraseña son obligatorios." });
  }

  // Consulta preparada (evita inyección SQL): los valores se pasan
  // como parámetros, nunca concatenados en el texto del SQL.
  const fila = db.prepare("SELECT * FROM usuarios WHERE usuario = ? AND password = ?")
    .get(usuario, password);

  if (!fila) {
    return res.status(401).json({ ok: false, mensaje: "Credenciales inválidas." });
  }

  // Crea la sesión: express-session guarda el id en una cookie
  // firmada en el navegador y los datos en el servidor.
  req.session.usuario = { id: fila.id, usuario: fila.usuario, rol: fila.rol };

  return res.json({ ok: true, mensaje: "Sesión iniciada.", usuario: req.session.usuario });
});

/* --- POST /api/logout --- */
router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ ok: true, mensaje: "Sesión cerrada." });
  });
});

/* --- GET /api/sesion (consulta de estado, útil para el front) --- */
router.get("/sesion", (req, res) => {
  if (req.session && req.session.usuario) {
    return res.json({ ok: true, autenticado: true, usuario: req.session.usuario });
  }
  return res.json({ ok: true, autenticado: false });
});

module.exports = router;
