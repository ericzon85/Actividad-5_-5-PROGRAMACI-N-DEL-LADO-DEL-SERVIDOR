/* ============================================================
   server.js
   Punto de entrada del backend.
   - Levanta el servidor local (equivalente a activar XAMPP/Node).
   - Configura sesiones con cookie (express-session).
   - Sirve la interfaz cliente (carpeta /public).
   - Monta las rutas de autenticación y del CRUD de citas.
   ============================================================ */

const express = require("express");
const session = require("express-session");
const path = require("path");

const rutasAuth = require("./routes/auth");
const rutasCitas = require("./routes/citas");
const { requiereSesion } = require("./middleware/auth");

const app = express();
const PUERTO = process.env.PORT || 3000;

/* --- Middlewares globales --- */
// Procesa cuerpos de formularios (application/x-www-form-urlencoded)
// y JSON, para poder leerlos luego con req.body.
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Sesión basada en cookie firmada; el id vive en el navegador,
// los datos del usuario autenticado viven en el servidor.
app.use(session({
  secret: "clave-secreta-taller-citas", // en producción: variable de entorno
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 }, // 1 hora
}));

// Sirve los archivos estáticos del cliente (HTML/CSS/JS).
app.use(express.static(path.join(__dirname, "public")));

/* --- Rutas de la API --- */
app.use("/api", rutasAuth);
app.use("/api/citas", rutasCitas);

// Ruta protegida de ejemplo: solo accesible con sesión activa.
// Sirve la página del dashboard directamente desde el backend.
app.get("/dashboard", requiereSesion, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

/* --- Manejo simple de errores no controlados --- */
app.use((err, req, res, next) => {
  console.error("[Servidor] Error:", err.message);
  res.status(500).json({ ok: false, mensaje: "Error interno del servidor." });
});

app.listen(PUERTO, () => {
  console.log(`Servidor activo en http://localhost:${PUERTO}`);
  console.log("Login de prueba -> usuario: admin / password: admin123");
});
